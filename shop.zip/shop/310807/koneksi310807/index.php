<?php
$servername = "144.76.57.59";
$username = "u2595594_jFQHomWi82";
$password = "np+3DiG0a!00r^vE4M8WdCHQ";
$dbname = "s2595594_siamd";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
