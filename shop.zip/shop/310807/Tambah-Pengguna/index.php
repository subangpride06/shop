<?php
include '../koneksi310807/index.php'; // Sesuaikan dengan path yang benar untuk file koneksi.php

// Pastikan koneksi ke database berhasil

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mendapatkan data dari form
    $nama_depan = $_POST['nama_depan'];
    $nama_belakang = $_POST['nama_belakang'];
    $email = $_POST['email'];
    $nomor_hp = $_POST['nomor_hp'];
    $password = $_POST['password'];
    $repeat_password = $_POST['repeat_password'];

    // Query SQL untuk insert data ke tabel pengguna
    $sql = "INSERT INTO pengguna (nama_depan, nama_belakang, email, nomor_hp, password, repeat_password) 
            VALUES ('$nama_depan', '$nama_belakang', '$email', '$nomor_hp', '$password', '$repeat_password')";

    if ($conn->query($sql) === TRUE) {
        $message = "Pengguna berhasil ditambahkan.";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Menutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengguna</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5 mb-4">Tambah Pengguna</h2>
        <?php if (!empty($message)): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form action="index.php" method="post">
            <div class="form-group">
                <label for="nama_depan">Nama Depan:</label>
                <input type="text" class="form-control" id="nama_depan" name="nama_depan" required>
            </div>

            <div class="form-group">
                <label for="nama_belakang">Nama Belakang:</label>
                <input type="text" class="form-control" id="nama_belakang" name="nama_belakang" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="nomor_hp">Nomor HP:</label>
                <input type="tel" class="form-control" id="nomor_hp" name="nomor_hp" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="repeat_password">Ulangi Password:</label>
                <input type="password" class="form-control" id="repeat_password" name="repeat_password" required>
            </div>

            <button type="submit" class="btn btn-primary">Tambah Pengguna</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
