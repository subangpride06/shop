<?php
include '../koneksi310807/index.php';

// Pastikan semua input data telah diisi
if (!empty($_POST['id']) && !empty($_POST['nama_barang']) && !empty($_POST['harga_barang']) && !empty($_FILES['foto_barang']['name']) && !empty($_POST['waktu_penambahan'])) {
    // Escape input untuk menghindari SQL Injection
    $id = $conn->real_escape_string($_POST['id']);
    $nama_barang = $conn->real_escape_string($_POST['nama_barang']);
    $harga_barang = $conn->real_escape_string($_POST['harga_barang']);
    $waktu_penambahan = $conn->real_escape_string($_POST['waktu_penambahan']);

    // Proses unggah foto barang
    $target_dir = "../uploads/"; // Direktori untuk menyimpan file foto
    $foto_barang = $target_dir . basename($_FILES["foto_barang"]["name"]); // Path lengkap file foto
    
    // Mendapatkan ekstensi file
    $imageFileType = strtolower(pathinfo($foto_barang, PATHINFO_EXTENSION));

    // Generate nama baru untuk file
    $nama_baru = "image-" . uniqid() . "." . $imageFileType; // Nama baru dengan format image-<unik_id>.<ekstensi>

    $target_file = $target_dir . $nama_baru; // Path lengkap file dengan nama baru

    // Validasi file gambar
    $uploadOk = 1;
    $check = getimagesize($_FILES["foto_barang"]["tmp_name"]);
    if ($check === false) {
        echo "File bukan gambar.";
        $uploadOk = 0;
    }

    // Check ukuran file gambar (maksimal 500KB)
    if ($_FILES["foto_barang"]["size"] > 500000) {
        echo "Maaf, ukuran file terlalu besar.";
        $uploadOk = 0;
    }

    // Izinkan hanya format file tertentu (jpeg, jpg, png, gif)
    $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
    if (!in_array($imageFileType, $allowed_types)) {
        echo "Maaf, hanya file JPG, JPEG, PNG & GIF yang diperbolehkan.";
        $uploadOk = 0;
    }

    // Cek jika $uploadOk tidak berubah menjadi 0 oleh kesalahan
    if ($uploadOk == 0) {
        echo "Maaf, file Anda tidak diunggah.";
    // Jika semuanya ok, coba untuk unggah file
    } else {
        if (move_uploaded_file($_FILES["foto_barang"]["tmp_name"], $target_file)) {
            echo "File ". htmlspecialchars(basename($_FILES["foto_barang"]["name"])). " sudah berhasil diunggah dengan nama baru $nama_baru.";

            // Jika unggah berhasil, lakukan update data barang
            $sql = "UPDATE barang SET 
                    nama_barang = '$nama_barang',
                    harga_barang = '$harga_barang',
                    foto_barang = '$target_file',
                    waktu_penambahan_barang = '$waktu_penambahan'
                    WHERE id = '$id'";
            
            if ($conn->query($sql) === TRUE) {
                echo "Data barang dengan ID $id berhasil diperbarui.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Maaf, ada kesalahan saat mengunggah file.";
        }
    }
} else {
    echo "Silakan lengkapi semua input data.";
}

// Menutup koneksi database
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Barang</title>
</head>
<body>
    <h2>Update Barang</h2>
    <form action="index.php" method="post" enctype="multipart/form-data">
        <label for="id">ID Barang:</label><br>
        <input type="text" id="id" name="id" required><br><br>
        
        <label for="nama_barang">Nama Barang:</label><br>
        <input type="text" id="nama_barang" name="nama_barang" required><br><br>
        
        <label for="harga_barang">Harga Barang:</label><br>
        <input type="text" id="harga_barang" name="harga_barang" required><br><br>
        
        <label for="foto_barang">Foto Barang:</label><br>
        <input type="file" id="foto_barang" name="foto_barang" accept="image/*" required><br><br>
        
        <label for="waktu_penambahan">Waktu Penambahan:</label><br>
        <input type="datetime-local" id="waktu_penambahan" name="waktu_penambahan" required><br><br>
        
        <input type="submit" value="Update Barang">
    </form>
</body>
</html>
