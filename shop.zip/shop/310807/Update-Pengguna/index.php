<?php
include '../koneksi310807/index.php';

// Pastikan semua input data telah diisi
if (!empty($_POST['id']) && !empty($_POST['nama_depan']) && !empty($_POST['nama_belakang']) && !empty($_POST['email']) && !empty($_POST['nomor_hp']) && ! empty($_POST['password']) && ! empty($_POST['repeat_password'])) {
    // Escape input untuk menghindari SQL Injection
    $id = $conn->real_escape_string($_POST['id']);
    $nama_depan = $conn->real_escape_string($_POST['nama_depan']);
    $nama_belakang = $conn->real_escape_string($_POST['nama_belakang']);
    $email = $conn->real_escape_string($_POST['email']);
    $nomor_hp = $conn->real_escape_string($_POST['nomor_hp']);
    $password = $conn->real_escape_string($_POST['password']);
    $repeat_password = $conn->real_escape_string($_POST['repeat_password']);

            $sql = "UPDATE pengguna SET 
                    nama_depan = '$nama_depan',
                    nama_belakang = '$nama_belakang',
                    email = '$email',
                    nomor_hp = '$nomor_hp',
                    password = '$password',
                    repeat_password = '$repeat_password'
                    WHERE id = '$id'";
            
            if ($conn->query($sql) === TRUE) {
                echo "Data pengguna dengan ID $id berhasil diperbarui.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
    echo "Silakan lengkapi semua input data.";
}

// Menutup koneksi database
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Barang</title>
</head>
<body>
    <h2>Tambah Pengguna</h2>
    <form action="index.php" method="post">
        <label for="id">ID Barang:</label><br>
        <input type="text" id="id" name="id" required><br><br>
        <label for="nama_depan">Nama Depan:</label><br>
        <input type="text" id="nama_depan" name="nama_depan" required><br><br>

        <label for="nama_belakang">Nama Belakang:</label><br>
        <input type="text" id="nama_belakang" name="nama_belakang" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="nomor_hp">Nomor HP:</label><br>
        <input type="tel" id="nomor_hp" name="nomor_hp" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <label for="repeat_password">Ulangi Password:</label><br>
        <input type="password" id="repeat_password" name="repeat_password" required><br><br>

        <input type="submit" value="Tambah Pengguna">
    </form>
</body>
</html>
