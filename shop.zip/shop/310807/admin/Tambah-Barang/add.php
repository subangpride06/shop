<?php
include '../../koneksi310807/index.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_barang = $_POST['nama_barang'];
    $harga_barang = $_POST['harga_barang'];
    $waktu_penambahan_barang = $_POST['waktu_penambahan_barang'];

    // Proses upload file
    $target_dir = "../../uploads/";
    $target_file = $target_dir . basename($_FILES["foto_barang"]["name"]);
    
    if (move_uploaded_file($_FILES["foto_barang"]["tmp_name"], $target_file)) {
        // Query untuk menambahkan data
        $sql = "INSERT INTO barang (nama_barang, harga_barang, foto_barang, waktu_penambahan_barang) VALUES ('$nama_barang', $harga_barang, '$target_file', '$waktu_penambahan_barang')";
        
        if ($conn->query($sql) === TRUE) {
            header("location: ./index.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Terjadi kesalahan saat mengupload file.";
    }

    $conn->close();
}
?>
