<?php

@include 'config.php';

if(isset($_POST['add_to_cart'])){

   $nama_barang = $_POST['nama_barang'];
   $harga_barang = $_POST['harga_barang'];
   $foto_barang = $_POST['foto_barang'];
   $product_quantity = 1;

   $select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE nama_barang = '$nama_barang'");

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product already added to cart';
   }else{
      $insert_product = mysqli_query($conn, "INSERT INTO `cart`(nama_barang, harga_barang, foto_barang, quantity) VALUES('$nama_barang', '$harga_barang', '$foto_barang', '$product_quantity')");
      $message[] = 'product added to cart succesfully';
   }

}


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>barang</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
</head>
<body>
   
<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   };
};

?>

<?php include 'header.php'; ?>

<div class="container">

<section class="barang">

   <h1 class="heading">latest barang</h1>

   <div class="box-container">

      <?php
      
      $select_barang = mysqli_query($conn, "SELECT * FROM `barang`");
      if(mysqli_num_rows($select_barang) > 0){
         while($fetch_product = mysqli_fetch_assoc($select_barang)){
      ?>
      
      <form action="" method="post">
         <div class="box">
      <img src="<?php echo $fetch_product['foto_barang']; ?>" alt="" style="width:100px;">
            <h3><?php echo $fetch_product['nama_barang']; ?></h3>
            <div class="price">$<?php echo $fetch_product['harga_barang']; ?>/-</div>
            <input type="hidden" name="nama_barang" value="<?php echo $fetch_product['nama_barang']; ?>">
            <input type="hidden" name="harga_barang" value="<?php echo $fetch_product['harga_barang']; ?>">
            <input type="hidden" name="foto_barang" value="<?php echo $fetch_product['foto_barang']; ?>">
            <input type="submit" class="btn" value="add to cart" name="add_to_cart">
         </div>
      </form>

      <?php
         };
      };
      ?>

   </div>

</section>

</div>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
