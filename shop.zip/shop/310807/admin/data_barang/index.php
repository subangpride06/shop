<?php
session_start(); // Mulai sesi di bagian paling atas

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['email'])) {
    echo "<script>
        alert('Anda tidak memiliki izin untuk mengakses halaman ini. Silakan login terlebih dahulu.');
        window.location.href = '../';
    </script>";
    exit;
}

include '../../koneksi310807/index.php';

// Menghitung jumlah barang
$sql_barang = "SELECT * FROM barang";
$result_barang = $conn->query($sql_barang);
$jumlah_barang = $result_barang->num_rows;

// Menghitung jumlah pengguna
$sql_pengguna = "SELECT COUNT(*) as jumlah_pengguna FROM pengguna";
$result_pengguna = $conn->query($sql_pengguna);
$row_pengguna = $result_pengguna->fetch_assoc();
$jumlah_pengguna = $row_pengguna['jumlah_pengguna'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="icon" href="../../assets/bahan-gambar/default.png" type="image/icon">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Data Barang</title>
        <link href="../../assets/css/styles.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        
        <style>
            .bg-success {
                border: none;
                border-radius: 4px;
                height: 30px;
                color: white;
            }
        </style>
        
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="#">Dashboard Admin</a>
            <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <div class="input-group">
                    <input class="form-control" type="text" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" />
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button"><i class="fas fa-search"></i></button>
                    </div>
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ml-auto ml-md-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="#">Pengaturan</a>
                        <a class="dropdown-item" href="#">Aktivitas</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="login.html">Keluar</a>
                    </div>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="../admin">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                            <a class="nav-link collapsed" href="dashboard.php" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Tema
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="../../Tema/dark">Tema Dark</a>
                                    <a class="nav-link" href="../../Tema/light">Tema Light</a>
                                </nav>
                            </div>
                           
                                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Halaman
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                                        Autentikasi
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="../">Login</a>
                                            <a class="nav-link" href="../../tambah-admin">Tambah Admin</a>
                                            <a class="nav-link" href="../../forgot">Lupa Password</a>
                                        </nav>
                                    </div>
                                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                                        Error
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                   </a>
                                    <div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="../../Error/401">401 Page</a>
                                            <a class="nav-link" href="../../Error/404">404 Page</a>
                                            <a class="nav-link" href="../../Error/500">500 Page</a>
                                        </nav>
                                    </div>
                                    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAdd" aria-expanded="false" aria-controls="pagesCollapseAdd">
                                        Tambah Data
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseAdd" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="../../Tambah-Barang">Tambah Barang</a>
                                            <a class="nav-link" href="../../Tambah-Pengguna">Tambah Pengguna</a>
                                        </nav>
                                    </div>
                                                                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseUpdate" aria-expanded="false" aria-controls="pagesCollapseUpdate">
                                        Update Data
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseUpdate" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="../../Update-Barang">Update Barang</a>
                                            <a class="nav-link" href="../../Update-Pengguna">Update Pengguna</a>
                                        </nav>
                                    </div>
                                                                        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseDelete" aria-expanded="false" aria-controls="pagesCollapseDelete">
                                        Hapus Data
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="pagesCollapseDelete" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                        <nav class="sb-sidenav-menu-nested nav">
                                            <a class="nav-link" href="../../Delete-Barang">Hapus Barang</a>
                                            <a class="nav-link" href="../../Delete-Pengguna">Hapus Pengguna</a>
                                        </nav>
                                    </div>
                                </nav>
                            </div>
                            
                            
                            
                            <div class="sb-sidenav-menu-heading">Database</div>
                            <a class="nav-link active" href="#">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Barang
                            </a>
                            <a class="nav-link" href="../data_pengguna">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Pengguna
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Created By :</div>
                        Agustian Aryana
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Data Barang</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                            <li class="breadcrumb-item active">Data Barang</li>
                        </ol>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                Database Barang
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                           
                         <button class="btn btn-success mb-3" onclick="openAddModal()"><i class="bi bi-plus-lg"></i> Tambah Barang</button>                      
                           
                           <br>
                           <br>
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama Barang</th>
            <th>Harga Barang</th>
            <th>Foto Barang</th>
            <th>Waktu Penambahan</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($jumlah_barang > 0): ?>
            <?php while($row = $result_barang->fetch_assoc()): ?>
                <tr>
                    <?php
                // Mengubah jalur gambar dari ../uploads/ ke ../../uploads/
                $path_gambar = str_replace('../../uploads/', '../../uploads/', $row['foto_barang']);
            ?>
                    <td><?php echo htmlspecialchars($row["id"]); ?></td>
                    <td><?php echo htmlspecialchars($row["nama_barang"]); ?></td>
                    <td>Rp <?php echo number_format($row["harga_barang"], 2, ',', '.'); ?></td>
                    <td><img src="<?php echo htmlspecialchars($path_gambar); ?>" alt="Gambar Barang" style="width:100px;"></td>
                    <td><?php echo htmlspecialchars($row["waktu_penambahan_barang"]); ?></td>
                    <td>
                        <button class="btn btn-success" onclick="openEditModal(
                            '<?php echo htmlspecialchars($row["id"]); ?>',
                            '<?php echo htmlspecialchars($row["nama_barang"]); ?>',
                            '<?php echo htmlspecialchars($row["harga_barang"]); ?>',
                            '<?php echo htmlspecialchars($row["foto_barang"]); ?>',
                            '<?php echo htmlspecialchars($row["waktu_penambahan_barang"]); ?>'
                        )"><i class="bi bi-pencil-square"></i></button>
                        <button onclick="openDeleteModal(<?php echo htmlspecialchars($row['id']); ?>)" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                            </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">Tidak ada data barang</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>


<script>
    function openAddModal() {
            $('#addModal').modal('show');
        }

        function openDeleteModal(id) {
            document.getElementById('delete-id').value = id;
            $('#deleteModal').modal('show');
        }
</script>

                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php include 'delete_modal.php'; ?>
                <?php include 'add_modal.php'; ?>
                
                <!-- Modal untuk Edit Barang -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Update Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editForm" action="edit.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="edit-id" name="id">
                    
                    <div class="form-group">
                        <label for="edit-nama_barang">Nama Barang:</label>
                        <input type="text" class="form-control" id="edit-nama_barang" name="nama_barang" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-harga_barang">Harga Barang:</label>
                        <input type="text" class="form-control" id="edit-harga_barang" name="harga_barang" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-foto_barang">Foto Barang:</label>
                        <input type="file" class="form-control" id="edit-foto_barang" name="foto_barang" accept="image/*" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-waktu_penambahan">Waktu Penambahan:</label>
                        <input type="datetime-local" class="form-control" id="edit-waktu_penambahan" name="waktu_penambahan" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Update Barang</button>
                </form>
            </div>
        </div>
    </div>
</div>

                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted text-center">Copyright &copy; SIAMD 2024 | All Right Reserved</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        
        <script>
    function openEditModal(id, nama, harga, foto, waktu) {
        // Mengisi nilai input form dengan data barang
        document.getElementById('edit-id').value = id;
        document.getElementById('edit-nama_barang').value = nama;
        document.getElementById('edit-harga_barang').value = harga;
        document.getElementById('edit-waktu_penambahan').value = new Date(waktu).toISOString().slice(0, 16); // format datetime-local
        
        // Buka modal
        $('#editModal').modal('show');
    }

    function confirmDelete(id) {
        if (confirm("Apakah Anda yakin ingin menghapus barang ini?")) {
            window.location.href = "hapus_barang.php?id=" + id;
        }
    }
    
</script>

        
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../../assets/js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../../assets/demo/chart-area-demo.js"></script>
        <script src="../../assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="../../assets/demo/datatables-demo.js"></script>
    </body>
</html>
