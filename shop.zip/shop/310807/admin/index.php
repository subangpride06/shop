<?php
session_start();
include '../koneksi310807/index.php';

$error_message = '';
$berhasil = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query untuk mendapatkan admin berdasarkan email
    $sql = "SELECT * FROM admin WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verifikasi password
        if (password_verify($password, $row['password'])) {
            $_SESSION['email'] = $email;
            $_SESSION['nama_depan'] = $row['nama_depan'];
            $_SESSION['nama_belakang'] = $row['nama_belakang'];
            $_SESSION['nomor_hp'] = $row['nomor_hp'];
            $berhasil = 'Berhasil Login sebagai Admin';
            header("Location: admin");
            exit();
        } else {
            $error_message = 'Password salah';
        }
    } else {
        $error_message = 'Email tidak ditemukan';
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../../bahan-gambar/default.png" type="image/icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teleku V1</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .app {
            position: absolute;
            width: 100%;
            height: 100%;
            max-width: 1000px;
            background: #383838;
            border-left: 1px solid #eee;
            border-right: 1px solid #eee;
            color: white;
        }

        .app > .screen {
            display: block;
            width: 100%;
            height: 100%;
        }

        .screen .form {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            max-width: 400px;
        }

        .screen .form-input {
            width: 100%;
            margin: 20px 0px;
        }

        .screen h2 {
            margin-bottom: 20px;
            font-size: 30px;
            color: #eee;
            border-bottom: 4px solid #eee;
            padding: 5px 0px;
            text-align: center;
        }

        .screen .form-input label {
            display: block;
            margin-bottom: 5px;
        }

        .screen .form-input .username,
        .screen .form-input .password {
            width: 100%;
            padding: 10px;
            border: 1px solid #555;
            font-size: 16px;
            border-radius: 10px;
        }

        .screen .form-input .password {
            padding-right: 40px;
        }

        .screen .form-input button {
            padding: 10px 20px;
            background: #111;
            color: #eee;
            width: 100%;
            font-size: 16px;
            cursor: pointer;
            outline: none;
            border: none;
            border-radius: 10px;
        }

        .gambar {
            width: 80px;
            border-radius: 100%;
            text-align: center;
            margin-left: 35%;
        }

        .screen .form-input a {
            margin-left: 90px;
            color: white;
        }

        #togglePassword {
            position: absolute;
            right: 10px;
            font-size: 24px;
            cursor: pointer;
            margin-top: 6px;
            color: black;
        }
    </style>
</head>
<body>
    <div class="app">
        <div class="screen join-screen">
            <div class="form">
                <img src="../../bahan-gambar/default.png" alt="Logo" class="gambar">
                <h2>Masuk Ke Panel</h2>

                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($berhasil)): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $berhasil; ?>
                    </div>
                <?php endif; ?>

                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <div class="form-input">
                        <label>email</label>
                        <input class="username" type="text" id="email" name="email" required />
                    </div>
                    <div class="form-input">
                        <label>Password</label>
                        <input class="password" type="password" id="password" name="password" required />
                        <i id="togglePassword" class="bi bi-eye"></i>
                    </div>
                    <div class="form-input">
                        <button type="submit">Masuk</button>
                    </div>
                    <div class="form-input">
                        <a href="../register">Buat Akun Baru</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="errorModalLabel">Login Error</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    email atau password salah. Silakan coba lagi.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Tambahkan Bootstrap JS dan jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        document.getElementById('togglePassword').addEventListener('click', function () {
            const passwordField = document.getElementById('password');
            const toggleIcon = document.getElementById('togglePassword');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        });

        <?php if (!empty($error_message)): ?>
        $(document).ready(function() {
            alert('email atau Password Salah');
        });
        <?php endif; ?>
    </script>
</body>
</html>
