<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#viewModal"
    data-nama_depan="<?php echo htmlspecialchars($row["nama_depan"]); ?>"
    data-nama_belakang="<?php echo htmlspecialchars($row["nama_belakang"]); ?>"
    data-email="<?php echo htmlspecialchars($row["email"]); ?>"
    data-nomor_hp="<?php echo htmlspecialchars($row["nomor_hp"]); ?>">
    Lihat Profil
</a>
