<?php
include '../../koneksi310807/index.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $id = $conn->real_escape_string($_POST['id']);
    $nama_depan = $conn->real_escape_string($_POST['nama_depan']);
    $nama_belakang = $conn->real_escape_string($_POST['nama_belakang']);
    $email = $conn->real_escape_string($_POST['email']);
    $nomor_hp = $conn->real_escape_string($_POST['nomor_hp']);

    // Update data pengguna
    $sql = "UPDATE pengguna SET 
            nama_depan = '$nama_depan',
            nama_belakang = '$nama_belakang',
            email = '$email',
            nomor_hp = '$nomor_hp'
            WHERE id = '$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php"); // Redirect kembali ke halaman dashboard pengguna
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
