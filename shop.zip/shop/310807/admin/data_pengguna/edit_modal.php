<!-- Modal untuk Edit Barang -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Update Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editForm" action="edit.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="edit-id" name="id">
                    
                    <div class="form-group">
                        <label for="edit-nama_barang">Nama Barang:</label>
                        <input type="text" class="form-control" id="edit-nama_barang" name="nama_barang" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-harga_barang">Harga Barang:</label>
                        <input type="text" class="form-control" id="edit-harga_barang" name="harga_barang" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-foto_barang">Foto Barang:</label>
                        <input type="file" class="form-control" id="edit-foto_barang" name="foto_barang" accept="image/*" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-waktu_penambahan">Waktu Penambahan:</label>
                        <input type="datetime-local" class="form-control" id="edit-waktu_penambahan" name="waktu_penambahan" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Update Barang</button>
                </form>
            </div>
        </div>
    </div>
</div>        