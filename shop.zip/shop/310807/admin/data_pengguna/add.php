<?php
include '../../koneksi310807/index.php'; // Sesuaikan dengan path yang benar untuk file koneksi.php

// Pastikan koneksi ke database berhasil

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mendapatkan data dari form
    $nama_depan = $_POST['nama_depan'];
    $nama_belakang = $_POST['nama_belakang'];
    $email = $_POST['email'];
    $nomor_hp = $_POST['nomor_hp'];
    $password = $_POST['password'];
    $repeat_password = $_POST['repeat_password'];

    // Query SQL untuk insert data ke tabel pengguna
    $sql = "INSERT INTO pengguna (nama_depan, nama_belakang, email, nomor_hp, password, repeat_password) 
            VALUES ('$nama_depan', '$nama_belakang', '$email', '$nomor_hp', '$password', '$repeat_password')";

    if ($conn->query($sql) === TRUE) {
        header("location: index.php");
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Menutup koneksi
$conn->close();
?>