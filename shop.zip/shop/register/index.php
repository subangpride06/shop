<?php
include '../310807/koneksi310807/index.php'; // Sesuaikan dengan path yang benar untuk file koneksi.php

// Pastikan koneksi ke database berhasil
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Mendapatkan data dari form
    $nama_depan = $_POST['nama_depan'];
    $nama_belakang = $_POST['nama_belakang'];
    $email = $_POST['email']; // Menggunakan $_POST['email'] bukan $_FILES['email'] karena ini adalah input teks
    $nomor_hp = $_POST['nomor_hp'];
    $password = $_POST['password'];
    $repeat_password = $_POST['repeat_password'];

    // Validasi password
    if ($password !== $repeat_password) {
        echo "Password dan konfirmasi password tidak cocok.";
        exit;
    }

    // Hash password
    $password_hashed = password_hash($password, PASSWORD_BCRYPT);
    $repeat_password_hashed = password_hash($repeat_password, PASSWORD_BCRYPT);

    // Query SQL untuk insert data ke tabel pengguna
    $sql = "INSERT INTO pengguna (nama_depan, nama_belakang, email, nomor_hp, password, repeat_password) 
            VALUES ('$nama_depan', '$nama_belakang', '$email', '$nomor_hp', '$password_hashed', '$repeat_password_hashed')";

    if ($conn->query($sql) === TRUE) {
        header("location: ../login");
    } else {
        $error_message = 'Gagal Membuat Akun';
    }
}

// Menutup koneksi
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="../bahan-gambar/default.png" type="image/icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teleku V1</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" >
    <link rel="stylesheet" href="../gaya-halaman/styles.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    
</head>
<body>
    <div class="app">
        <div class="screen join-screen">
            <div class="form">
                <img src="../bahan-gambar/default.png" alt="Logo" class="gambar">
                <h2>Buat Akun Baru</h2>
                <form method="post" action="">
                  <?php
                  if (isset($error_message)) {
                    echo "<p style='color: red;'>$error_message</p>";
                  }
                  ?>
                    
                    <div class="form-input">
                        <label class="label-depan">Nama Depan</label>
                        <input class="nama-depan" type="text" id="nama_depan" name="nama_depan" required />
                    </div>
                    
                    <div class="form-input">
                        <label>Nama Belakang</label>
                        <input class="nama-belakang" type="text" id="nama_belakang" name="nama_belakang" required />
                    </div>
                    
                    <div class="form-input">
                        <label>email</label>
                        <input class="email" type="text" id="email" name="email" required />
                    </div>
                    
                    <div class="form-input">
                        <label>Nomor Handphone</label>
                        <input class="nomor-hp" type="number" id="nomor_hp" name="nomor_hp" required />
                    </div>
                    
                    <div class="form-input">
                        <label>Password</label>
                        <input class="password" type="password" id="password" name="password" required />
                        
                     <div class="form-input">
                        <label>Konfirmasi Password</label>
                        <input class="repeat-password" type="password" id="repeat_password" name="repeat_password" required />
                    </div>
                        <i id="togglePassword1" class="bi bi-eye"></i>
                        <i id="togglePassword2" class="bi bi-eye"></i>
                    </div>
                    <div class="form-input">
                        <button type="submit">Masuk</button>
                    </div>
                    <div class="form-input">
                       <p>Sudah Punya Akun? <a href="../login">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
   

    <!-- Tambahkan Bootstrap JS dan jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script> document.getElementById('togglePassword1').addEventListener('click', function () {
            const passwordField = document.getElementById('password');
            const toggleIcon = document.getElementById('togglePassword1');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        });

        <?php if ($login_error): ?>
        $(document).ready(function() {
            alert('email Atau Password Salah')
        });
        <?php endif; ?>
        
        document.getElementById('togglePassword2').addEventListener('click', function () {
            const passwordField = document.getElementById('repeat_password');
            const toggleIcon = document.getElementById('togglePassword2');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        });

        <?php if ($login_error): ?>
        $(document).ready(function() {
            alert('email Atau Password Salah')
        });
        <?php endif; ?>
    </script>
</body>
</html>
