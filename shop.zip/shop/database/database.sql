-- Setup Database and Tables for Shop DB

-- Create Database
/*CREATE DATABASE IF NOT EXISTS shop_db;
USE shop_db;*/

-- Create Table: barang
CREATE TABLE IF NOT EXISTS barang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_barang VARCHAR(255) NOT NULL,
    harga_barang DECIMAL(10, 2) NOT NULL,
    foto_barang VARCHAR(255) NOT NULL,
    waktu_penambahan_barang TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Create Table: admin
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    nama_depan VARCHAR(255),
    nama_belakang VARCHAR(255),
    nomor_hp VARCHAR(20)
);


-- add default account admin
INSERT INTO admin (email, password, nama_depan, nama_belakang, nomor_hp) 
VALUES ('aryanaoffc@gmail.com', '$2y$10$AOB7CRE53LCaCtn6izerZuZb9103zUu2cfPt6xTdl6qYY1ZbR0Rky', 'Admin', 'User', '6285210589861');
-- Password : aryanaoffc310807


-- Create Table: pengguna
CREATE TABLE IF NOT EXISTS pengguna (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_depan VARCHAR(255) NOT NULL,
    nama_belakang VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    nomor_hp VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    repeat_password VARCHAR(255) NOT NULL
);

-- Create Table: cart
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    nama_barang VARCHAR(255) NOT NULL,
    harga_barang DECIMAL(10, 2) NOT NULL,
    foto_barang VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Status Order
CREATE TABLE order_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Bantuan Jika Error
-- Jika Kamu Bingung Dengan Kode Di Atas Atau Kode Di Atas Error, Kamu Bisa Kirim Pesan Lewat Whatsapp/Email Dibawah :
-- WhatsApp : 085210589861
-- Email : aryanaoffc@gmail.com

-- Selamat Menggunakan Website
