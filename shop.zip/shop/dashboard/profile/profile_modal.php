<div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Profile Pengguna</h5>
            </div>
            <div class="modal-body">
                <form method="post" action="update.php">
                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
                    
                    <div class="form-group">
                        <label>Nama Depan:</label>
                        <input type="text" class="form-control" name="nama_depan" value="<?php echo htmlspecialchars($user['nama_depan']); ?>" required>
                    </div>
                    
                    <br>
                    
                    <div class="form-group">
                        <label>Nama Belakang:</label>
                        <input type="text" class="form-control" name="nama_belakang" value="<?php echo htmlspecialchars($user['nama_belakang']); ?>" required>
                    </div>
                    
                    <br>
                    
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                    
                    <br>
                    
                    <div class="form-group">
                        <label>Nomor Telepon:</label>
                        <input type="text" class="form-control" name="nomor_hp" value="<?php echo htmlspecialchars($user['nomor_hp']); ?>" required>
                    </div>
                    
                    <br>
                    
                    <div class="form-group">
                        <label>Password:</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    
                    <br>
                    
                    <div class="form-group">
                        <label>Konfirmasi Password:</label>
                        <input type="password" class="form-control" name="repeat_password">
                    </div>
                    
                    <br>
                    
                    <button type="submit" class="btn btn-primary mt-2">Update</button>
                    <button type="submit" class="btn btn-danger" data-dismiss="modal">Cencel</button>
                </form>
            </div>
        </div>
    </div>
</div>
