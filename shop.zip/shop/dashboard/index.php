<?php
session_start();
include '../310807/koneksi310807/index.php';

// Misalkan Anda menyimpan email pengguna yang login di sesi
$email = $_SESSION['email'];

// Query untuk mendapatkan data pengguna yang login
$sql_user = "SELECT * FROM pengguna WHERE email = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("s", $email);
$stmt->execute();
$result_user = $stmt->get_result();
$user = $result_user->fetch_assoc();

// Memastikan bahwa pengguna ditemukan
if (!$user) {
    header("location: ../../");
    exit;
}

// Query untuk mendapatkan data cart berdasarkan pengguna yang login
$sql_cart = "SELECT * FROM cart WHERE email = ?";
$stmt_cart = $conn->prepare($sql_cart);
$stmt_cart->bind_param("s", $email);
$stmt_cart->execute();
$result_cart = $stmt_cart->get_result();
$jumlah_cart = $result_cart->num_rows;

// Menghitung jumlah barang
$sql_barang = "SELECT * FROM barang";
$result_barang = $conn->query($sql_barang);
$jumlah_barang = $result_barang->num_rows;

// Menghitung jumlah pengguna
$sql_pengguna = "SELECT COUNT(*) as jumlah_pengguna FROM pengguna";
$result_pengguna = $conn->query($sql_pengguna);
$row_pengguna = $result_pengguna->fetch_assoc();
$jumlah_pengguna = $row_pengguna['jumlah_pengguna'];

if(isset($_POST['add_to_cart'])){

   $nama_barang = $_POST['nama_barang'];
   $harga_barang = $_POST['harga_barang'];
   $foto_barang = $_POST['foto_barang'];
   $product_quantity = 1;

   $select_cart = $conn->prepare("SELECT * FROM cart WHERE email = ? AND nama_barang = ?");
   $select_cart->bind_param("ss", $email, $nama_barang);
   $select_cart->execute();
   $result_select_cart = $select_cart->get_result();

   if($result_select_cart->num_rows > 0){
      $message[] = 'Product already added to cart';
   }else{
      $insert_product = $conn->prepare("INSERT INTO cart (email, nama_barang, harga_barang, foto_barang, quantity) VALUES (?, ?, ?, ?, ?)");
      $insert_product->bind_param("ssssd", $email, $nama_barang, $harga_barang, $foto_barang, $product_quantity);
      $insert_product->execute();
      $addtocart[] = 'product added to cart succesfully';
   }
}

// Menghitung total harga di keranjang
$total_harga = 0; // Variabel untuk menyimpan total harga

if ($jumlah_cart > 0) {
    while ($row = $result_cart->fetch_assoc()) {
        // Menghitung subtotal harga untuk setiap barang
        $subtotal = $row['harga_barang'] * $row['quantity'];
        
        // Menambahkan subtotal ke total harga
        $total_harga += $subtotal;
    }
}

$total_harga_format = number_format($total_harga, 2, ',', '.'); 

// Logika untuk memperbarui quantity
$update_success = false;

if (isset($_POST['update_update_btn'])) {
    // Ambil nilai dari form
    $update_quantity_id = intval($_POST['update_quantity_id']);
    $update_quantity = intval($_POST['update_quantity']);

    // Update quantity di database
    $update_query = "UPDATE cart SET quantity = ? WHERE id = ? AND email = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('iis', $update_quantity, $update_quantity_id, $email);

    if ($stmt->execute()) {
        $update_success = true;
        $message_oke = "Data Berhasil Di Ubah";
    } else {
        $message_error = "Terjadi Kesalahan Saat Memperbarui Data Barang!";
    }

    $stmt->close();
}

// Ambil data keranjang dari database berdasarkan email pengguna
$query = "SELECT * FROM cart WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email);
$stmt->execute();
$result_cart = $stmt->get_result();
$jumlah_cart = $result_cart->num_rows;

$conn->close();
?>






<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../bahan-gambar/default.png" type="image/icon">
    <title>Teleku V1</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
      .keranjang i {
        font-size: 1.3rem;
        position: absolute;
        right: 40px;
        top: 13px;
      }
      
      .btn-group {
            position: absolute;
            right: 16px;
            top: 18px;
        }
        .dropdown-toggle {
            width: 30px; /* Sesuaikan width tombol */
            background-color: white; /* Atur background menjadi putih atau transparent */
            border: none; /* Hilangkan border */
            padding: 0; /* Hilangkan padding */
        }
        .dropdown-toggle:focus {
            box-shadow: none; /* Hilangkan shadow pada fokus */
        }
        .dropdown-menu {
            border-radius: 10px; /* Tambahkan border-radius */
        }
        
        .dropdown-toggle i {
            font-size: 20px;
        }
      
      .nav-item {
        background: #77b5fb;
        height: 30px;
        border-radius: 4px;
        transform: translateX(px);
        color: black;
      }
      
      ul {
        
      }
      
      ul li a {
        color: white;
      }
      
      button {
        border: none;
        outline: none;
        background: white;
      }
      
      .input {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      
      .search {
        width: 80%;
        align-items: center;
        transform: translateY(-20px);
        height: 35px;
        border-radius: 20px;
        padding: 0px 35px 0px 20px;
        border: none;
        box-shadow: 0 0 3px black;
        margin-left: 15px;
      }
      
      .input i {
        font-size: 2rem;
      }
      
      #togglePassword {
    position: relative;
    right: 35px; /* Menempatkan ikon di sebelah kanan input */
    font-size: 24px;
    cursor: pointer;
    margin-top: -38px;
    color: black;
}
      
      .row {
          margin-top: 40px;
          padding: 20px;
      }
      
      
nav {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
    padding: 20px;
}

nav .dp {
    padding: 5px 10px;
    background-color: #a0a0af;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    font-size: 14px;
    width: 140px; /* Lebar tombol lebih panjang */
    height: 30px; /* Tinggi tombol lebih kecil */
    white-space: nowrap; /* Mencegah teks menumpuk ke bawah */
}

nav button:hover {
    background-color: #0056b3;
}

.product-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
}

.product-card {
    background-color: white;
    border: 1px solid #ddd;    
    border-radius: 8px;
    padding: 20px;
    width: 320px;
    box-shadow: 0px 0px 5px black;
}

.product-card img {
    width: 114%;
    height: auto;
    border-radius: 8px;
    margin-left: -20px;
    margin-top: -19px;
    
}

.product-card .nama {
    color: black;
    margin-top: 40px;
    white-space: nowrap;
    font-weight: 800;
}

.product-card .harga {
    color: red;
    font-weight: bold;
    margin-right: 180px;
    margin-top: -20px;
    white-space: nowrap;
}

.rating {
    color: gold;
    margin-top: -43px;
    margin-left: 200px;
    font-size: 1.2rem;
}

.nama_brand {
    width: 125px;
}

.nama_brand_footer {
    width: 150px;
}

        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            text-align: center;
            border-top: 1px solid #dee2e6;
            margin-top: 80px;
        }
        .footer h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        .footer p {
            margin: 5px 0;
            font-size: 1rem;
            color: #6c757d;
        }
        .footer .payment-methods {
            margin: 20px 0;
        }
        .footer .payment-methods img {
            margin: 0 5px;
            height: 30px;
        }
        .footer .social-icons {
            margin: 10px 0;
        }
        .footer .social-icons a {
            margin: 0 10px;
            text-decoration: none;
            color: #343a40;
            font-size: 1.2rem;
        }
        .footer .copyright {
            margin: 10px 0;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .badge {
            transform: translateX(-10px);
        }
        
        .hasil {
            color: red;
            transform: translateY(-10px);
            background: transparent;
            
        }
        
        .btn.btn-primary {
             transform: translateY(-5px); 
            <!-- margin-top: -10px; -->
        }
        
      .cart-item {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .cart-item img {
            width: 50px;
            height: 50px;
            margin-right: 10px;
        }
        .cart-item-details {
            flex-grow: 1;
        }
        .cart-item-price {
            color: #ff007b;
            font-weight: bold;
        }
        .modal-footer {
            display: flex;
            justify-content: space-between;
        }
    .close {
        margin-left: auto;
        color: #000;
        opacity: 1;
    }
    .card.ttl {
        width: 200px;
        margin-left: 20px;
        text-align: center;
        margin-top: -10px;
        
    }
    
    .card.ttl p {
        transform: translateY(8px);
        font-weight: 800;
    }
    
    .card.cart {
        margin-bottom: 25px;
        height: 120px;
    }
    
    .foto-b {
        transform: translateX(10px);
        width: 104px;
        border-radius: 4px;
    }
    
    .foto-b img {
        border-radius: 4px;
        box-shadow: 0px 0px 3px black;
        transform: translateY(25px);
    }
    
    .nama-b {
        font-weight: 800;
        margin-left: 120px;
        margin-top: -60px;
    }
    
    .harga-b {
        font-weight: 800;
        color: #ff55f3;
        margin-left: 120px;
        transform: translateY(-20px);
    }
    
    .qty {
        width: 30px;
        height: 25px;
        margin-left: 120px;
        transform: translateY(-36px);
        text-align: center;
        border: 1px solid black;
        border-radius: 4px;
    }
    
    .edit {
            transform: translateY(-61px);
            background: #ffb32af4;
            width: 40px;
            height: 25px;
            color: white;
            border-radius: 4px;
            margin-left: 160px;
        }
        
    .hapus {
            transform: translateY(-86px);
            background: red;
            width: 40px;
            height: 25px;
            color: white;
            border-radius: 4px;
            margin-left: 210px;
        }
        
        .note {
            color: red;
            width: 240px;
            margin-left: 20px;
        }
        
      .whatsapp {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 60px;
    height: 60px;
    background-color: #3ac04c;
    border-radius: 50%;
    background-image: url('https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg');
    background-size: 50%;
    background-position: center;
    background-repeat: no-repeat;
    cursor: pointer;
}

.modal.bantuan-modal {
    display: none; 
    position: fixed;
    z-index: 1;
    left: 0;
    top: 80px;
    width: 100%;
    height: 100%;
    overflow: auto;
}

.modal-content.bantuan-modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 400px;
    border-radius: 10px;
}

.modal-content.bantuan-modal-content h3 {
    transform: translateY(-35px);
}

.modal.bantuan-modal .close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.modal.bantuan-modal .close:hover,
.modal.bantuan-modal .close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

.modal.bantuan-modal form {
    display: flex;
    flex-direction: column;
}

.modal.bantuan-modal input[type="text"],
.modal.bantuan-modal textarea {
    margin-bottom: 10px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.modal.bantuan-modal button {
    padding: 10px;
    background-color: #3ac04c;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.modal.bantuan-modal button:hover {
    background-color: #34a939;
}

    </style>
  </head>
  <body>
    <?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="modal-body">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <p>Produk Tidak Bisa Ditambahkan, Karena Telah Tersimpan Di Dalam Keranjang</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>';
   };
};

?>

<?php

if(isset($addtocart)){
   foreach($addtocart as $addtocart){
      echo '<div class="modal-body">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <p>Berhasil Menambahkan Produk Kedalam Keranjang</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>';
   };
};

?>

<?php if ($update_success): ?>
    <div class="modal-body">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <p>Jumlah Pesanan Telah Berhasil Diperbarui Silahkan Refresh Agar Total Harga Dapat Muncul Dan Tidak Error</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>


   <nav class="navbar navbar-expand-lg bg-light sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img class="nama_brand" src="../bahan-gambar/63a52a35c01dd_A.png" alt="">
        </a>
        
         <div class="btn-group">
            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <?php if(isset($_SESSION['email'])): ?>
                    <li><a href="#" class="dropdown-item" data-toggle="modal" data-target="#profileModal">Lihat Profil Saya</a></li>
                    <li><a class="dropdown-item" href="#">History</a></li>
                    <li><a class="dropdown-item" data-toggle="modal" data-target="#aboutModal"> Tentang Toko </a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../logout">Logout</a></li>
                <?php else: ?>
                    <li><a class="dropdown-item" href="../../">Login</a></li>
                    <li><a class="dropdown-item" href="../register">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
        
        <div class="keranjang" aria-labelledby="userDropdown">
    <a href="#" data-toggle="modal" data-target="#cartModal">
        <i class="bi bi-bag-check-fill">
            <span class="badge">
                <p class="hasil">
                   <?php echo $jumlah_cart; ?>
                </p>
            </span>
        </i>
    </a>
</div>

    </div>
</nav>
    
     <div id="carouselExampleAutoplaying" class="carousel slide " style="margin-top: -20px;" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../bahan-gambar/1719234591636.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="../bahan-gambar/1719234591636.jpg" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="../bahan-gambar/1719234591636.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
<!--   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button> -->
</div> 
    
            <div class="input">
  <input type="text" class="search" placeholder="Cari Produk">
  <i id="togglePassword" class="bi bi-search"></i>
</div>
    
        <nav>
            <button class="dp active">All</button>
            <button class="dp" onclick="otw()">OTW</button>
            <button class="dp" onclick="otw()">OTW</button>
            <button class="dp" onclick="otw()">OTW</button>
        </nav>
    
    
   <main>

<div class="product-list">
    <?php if ($jumlah_barang > 0): ?>
        <?php while($row = $result_barang->fetch_assoc()): ?>
            <?php
                // Mengubah jalur gambar dari ../310807/uploads/ ke ../../uploads/
                $path_gambar = str_replace('../../uploads/', '../310807/uploads/', $row['foto_barang']);
            ?>
            <form action="" method="post">
                <div class="product-card">
                    <?php echo '<img src="' . htmlspecialchars($path_gambar) . '" alt="Gambar Barang">'; ?>
                    <?php echo '<p class="nama">' . htmlspecialchars($row["nama_barang"]) . '</p>'; ?>
                    <?php echo '<p class="harga">Rp ' . number_format($row["harga_barang"], 2, ',', '.') . '</p>'; ?>
                    <?php echo '<input type="hidden" name="nama_barang" value="' . htmlspecialchars($row['nama_barang']) . '">'; ?>
                    <?php echo '<input type="hidden" name="harga_barang" value="' . htmlspecialchars($row['harga_barang']) . '">'; ?>
                    <?php echo '<input type="hidden" name="foto_barang" value="' . htmlspecialchars($path_gambar) . '">'; ?>
                    <?php echo '<input type="submit" class="btn btn-primary" value=" Tambah Keranjang" name="add_to_cart">'; ?>
                   
                    <div class="rating">★★★★★</div>
                </div>
            </form>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Tidak ada data barang</p>
    <?php endif; ?>
</div>

</main>

    
<!-- Footer Section -->
<div class="footer">
    <img class="nama_brand_footer" src="../bahan-gambar/63a52a35c01dd_A.png" alt="">
    <br>
    <p>digital marketplace yang menyediakan berbagai layanan digital seperti suntik followers, panel pterodactyl, script bot whatsapp, dll.</p>
    <div class="payment-methods">
        <img src="../bahan-gambar/bca.png" alt="BCA">
        <img src="../bahan-gambar/mandiri.png" alt="Mandiri">
        <img src="../bahan-gambar/bni.png" alt="BNI">
        <img src="../bahan-gambar/ovo.png" alt="OVO">
        <img src="../bahan-gambar/gopay.png" alt="Gopay">
        <img src="../bahan-gambar/dana.png" alt="Dana">
    </div>
    <br>
    <div class="copyright">
       Copyright &copy; SIAMD 2024 | All Right Reserved
    </div>
</div>
    
   <a href="#" class="whatsapp" id="whatsappIcon"></a>
   
   <?php 
   include 'cart/cart_modal.php'; 
   ?>
   <?php 
   include 'delete/delete_modal.php'; 
   ?>
   <?php 
   include 'profile/profile_modal.php'; 
   ?>
   <?php 
   include 'about/about_modal.php'; 
   ?>
   <?php
   include 'bantuan/index.php';
   ?>


<script>
    
    function otw() {
        alert("Maaf Fitur Ini Tidak Dapat Digunakan Karena Website Sedang Dalam Pengembangan Oleh Develover. 🙏");
    }
    
    let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .navbar');

menu.onclick = () =>{
   menu.classList.toggle('fa-times');
   navbar.classList.toggle('active');
};

window.onscroll = () =>{
   menu.classList.remove('fa-times');
   navbar.classList.remove('active');
};


document.querySelector('#close-edit').onclick = () =>{
   document.querySelector('.edit-form-container').style.display = 'none';
   window.location.href = 'index.php.php';
};

function chek() {
    window.location.href = "checkout";
}

function openDeleteModal(id) {
            document.getElementById('delete-id').value = id;
            $('#deleteModal').modal('show');
        }        
    
</script>

    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/chart-area-demo.js"></script>
        <script src="../assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/datatables-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="script.js"></script>
  </body>
</html>
