
    <div id="bantuanModal" class="modal bantuan-modal">
        <div class="modal-content bantuan-modal-content">
            <span class="close" aria-hidden="true">&times;</span>
            <h3>Form Bantuan</h3>
            <form id="formBantuan">
                <input type="text" id="modalNama" placeholder="Nama" required>
                <textarea id="modalPesan" placeholder="Tulis pesan.." required></textarea>
                <button type="submit">KIRIM</button>
                <div class="text-center"> <div class="spinner-border" role="status"> <span class="visually-hidden">Loading...</span> </div> </div>
            </form>
        </div>
    </div>
