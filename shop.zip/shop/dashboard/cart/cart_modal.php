<div class="modal fade" id="cartModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title" id="exampleModalLabel">
          <b>Keranjang Belanja</b>
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" class="close">&times;</span>
        </button>
      </div>
      
      <div class="modal-body">
        <?php if ($jumlah_cart > 0): ?>
          <?php while($row = $result_cart->fetch_assoc()): ?>
             <div class="card cart">
              <?php
                // Mengubah jalur gambar dari ../uploads/ ke ../../uploads/
                $path_gambar = str_replace('../310807/uploads/', '../../310807/uploads/', $row['foto_barang']);
              ?>
              <p class="foto-b"><?php echo '<img src="' . htmlspecialchars($path_gambar) . '" alt="Gambar Barang" style="width: 100px;">'; ?></p>
              <p class="nama-b"><?php echo htmlspecialchars($row["nama_barang"]); ?></p>
              <p class="harga-b">Rp <?php echo number_format($row["harga_barang"], 2, ',', '.'); ?></p>
              <form action="" method="post">
                <input type="hidden" name="update_quantity_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                <input class="qty" type="number" name="update_quantity" min="1" value="<?php echo isset($row['quantity']) ? htmlspecialchars($row['quantity']) : 1; ?>">
                <button class="edit" type="submit" value="update" name="update_update_btn"><i class="bi bi-pencil-square"></i></button>
              </form>
              <button onclick="openDeleteModal(<?php echo htmlspecialchars($row['id']); ?>)"" class="hapus"><i class="bi bi-trash-fill"></i></button>                         
                
            </div>
          <?php endwhile; ?>
        <?php else: ?>
          <p>Tidak ada barang</p>
        <?php endif; ?>
      </div>
      
      <div class="card ttl">
          <p class="total">Total Harga : <?php echo $total_harga_format; ?></p>
      </div>
      
      <br>
      
      <div class="modal-footer border-top-0 d-flex justify-content-between">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-success" onclick="chek()">Checkout</button>
      </div>
  </div>
</div>
</div>
