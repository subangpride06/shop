<!-- Modal -->
<div class="modal fade" id="aboutModal" tabindex="-1" role="dialog" aria-labelledby="aboutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title" id="aboutModalLabel">Tentang Toko Kami</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h6><b>Sejarah Toko<!--  --></b></h6>
        <p>Toko kami didirikan pada tahun 2024 dengan tujuan menyediakan produk berkualitas tinggi kepada pelanggan kami. Kami selalu berusaha untuk memberikan pelayanan terbaik dan produk yang memuaskan.</p>
        
        <h6><b>Misi Kami</b></h6>
        <p>Misi kami adalah untuk menjadi toko terdepan yang dikenal karena produk dan layanan yang unggul. Kami berkomitmen untuk menciptakan pengalaman belanja yang luar biasa bagi setiap pelanggan.</p>

        <h6><b>Nilai-Nilai Kami</b></h6>
        <p>Kami percaya pada kejujuran, integritas, dan kepuasan pelanggan. Kami bekerja keras untuk memastikan bahwa setiap interaksi dengan pelanggan kami adalah positif dan berkesan.</p>

        <h6><b>Produk Kami</b></h6>
        <p>Kami menawarkan berbagai produk mulai dari A hingga Z, semuanya dipilih dengan cermat untuk memenuhi kebutuhan dan keinginan pelanggan kami. Kualitas adalah prioritas utama kami.</p>

        <h6><b>Hubungi Kami</b></h6>
        <p>Jika Anda memiliki pertanyaan atau membutuhkan bantuan, jangan ragu untuk menghubungi kami melalui email di <a href="mailto:aryanaoffc@gmail.com">aryanaoffc@gmail.com</a> atau melalui telepon di <a href="https://wa.me/6285210589861">+62 852-1058-9861</a>.</p>
      </div>
      <div class="modal-footer border-top-0 d-flex justify-content-between">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>