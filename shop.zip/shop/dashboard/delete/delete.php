<?php
include '../../310807/koneksi310807/index.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil ID dari formulir
    $id_to_delete = intval($_POST['id']);

    // Hapus data barang dengan ID yang ditentukan
    $sql_delete = "DELETE FROM cart WHERE id = $id_to_delete";
    if ($conn->query($sql_delete) === TRUE) {
        echo "Data dengan ID $id_to_delete berhasil dihapus.<br>";

        // Perbarui semua ID yang lebih besar dari ID yang dihapus
        $sql_update_ids = "UPDATE cart SET id = id - 1 WHERE id > $id_to_delete";
        if ($conn->query($sql_update_ids) === TRUE) {
            echo "ID barang telah diperbarui agar tetap berurutan.<br>";

            // Set ulang auto-increment agar sesuai dengan ID terakhir + 1
            $sql_reset_auto_increment = "ALTER TABLE barang AUTO_INCREMENT = " . ($conn->query("SELECT MAX(id) FROM cart")->fetch_assoc()['MAX(id)'] + 1);
            if ($conn->query($sql_reset_auto_increment) === TRUE) {
                echo "Auto-increment tabel barang telah diatur ulang.<br>";
            } else {
                echo "Error saat mengatur ulang auto-increment: " . $conn->error . "<br>";
            }
        } else {
            echo "Error saat memperbarui ID barang: " . $conn->error . "<br>";
        }
    } else {
        echo "Error saat menghapus data: " . $conn->error . "<br>";
    }

    // Menutup koneksi database
    $conn->close();

    // Redirect kembali ke halaman utama setelah penghapusan
    header("Location: ../");
    exit();
}
?>
