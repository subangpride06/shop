function sendToWhatsApp() {
    var nama = document.getElementById("nama").value.trim();
    var nomor = document.getElementById("nomor").value.trim();
    var kupon = document.querySelector("input[aria-label='Kupon']").value.trim();
    var paymentOption = document.querySelector('.payment-option.selected');

    if (!nama) {
        alert("Nama Tidak Boleh Kosong!");
        document.getElementById("nama").focus();
        return;
    }

    if (!nomor) {
        alert("Nomor WhatsApp Tidak Boleh Kosong!");
        document.getElementById("nomor").focus();
        return;
    }

    if (!paymentOption) {
        alert("Tolong Pilih Metode Pembayaran!");
        return;
    }

    var metodePembayaran = paymentOption.alt;

    // Pesan 1: Detail Pesanan
    var pesan1 = `Hi Kak, saya mau order\n\n`;

    // Loop untuk menambahkan detail setiap item di keranjang
    var items = document.querySelectorAll('.card.cart');
    items.forEach((item, index) => {
        var namaBarang = item.querySelector('.nama-b').textContent.trim();
        var quantity = item.querySelector('.qty').value.trim();
        var harga = item.querySelector('.harga-b').textContent.trim();

        pesan1 += `*${index + 1}: ${namaBarang}*\nJumlah: ${quantity}\nHarga Satuan: ${harga}\n\n`;
    });

    // Pesan 2: Detail Pembayaran
    var totalHarga = document.getElementById("totalHarga").textContent.trim();
    var potongan = document.getElementById("potongan").textContent.trim();
    var total = document.getElementById("total").textContent.trim();

    var pesan2 = `Subtotal: *${totalHarga}*\nPotongan: *${potongan}*\nTotal: *${total}*\n━━━━━━━━━━━━━━\n\n`;
    var pesan3 = `Nama: *${nama}*\nNomor WhatsApp: *${nomor}*\nKupon: ${kupon}\nMetode Pembayaran: *${metodePembayaran}*`;

    var pesanLengkap = `${pesan1}${pesan2}${pesan3}`;

    var url = `https://wa.me/6282320319958?text=${encodeURIComponent(pesanLengkap)}`;
    window.open(url, '_blank');
}

function applyCoupon() {
    var kuponInput = document.querySelector("input[aria-label='Kupon']");
    var potonganText = document.getElementById("potongan");
    var totalText = document.getElementById("total");

    var kupon = kuponInput.value.trim();
    var totalHarga = parseFloat(document.getElementById("totalHarga").textContent.replace(/[^0-9,-]+/g, "").replace(',', '.'));

    var potongan = 0;

    if (kupon === "NEWMEMBERS") {
        potongan = 5000;
    }
    
    if (kupon === "SPECIAL100K") {
        potongan = 100000;
    }

    potonganText.textContent = "Rp. " + potongan.toLocaleString('id-ID', { minimumFractionDigits: 2 });
    var total = totalHarga - potongan;
    totalText.textContent = "Rp. " + total.toLocaleString('id-ID', { minimumFractionDigits: 2 });
}

function selectPaymentOption(event) {
    var options = document.querySelectorAll('.payment-option');
    options.forEach(option => {
        option.classList.remove('selected');
    });
    event.target.classList.add('selected');
}
