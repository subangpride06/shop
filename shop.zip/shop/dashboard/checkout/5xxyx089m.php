<?php
session_start();
include '../../310807/koneksi310807/index.php';

// Misalkan Anda menyimpan email pengguna yang login di sesi
$email = $_SESSION['email'];

// Query untuk mendapatkan data pengguna yang login
$sql_user = "SELECT * FROM pengguna WHERE email = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("s", $email);
$stmt->execute();
$result_user = $stmt->get_result();
$user = $result_user->fetch_assoc();

// Memastikan bahwa pengguna ditemukan
if (!$user) {
    header("location: ../../login");
    exit;
}

// Query untuk mendapatkan data cart berdasarkan pengguna yang login
$sql_cart = "SELECT * FROM cart WHERE email = ?";
$stmt_cart = $conn->prepare($sql_cart);
$stmt_cart->bind_param("s", $email);
$stmt_cart->execute();
$result_cart = $stmt_cart->get_result();
$jumlah_cart = $result_cart->num_rows;

// Menghitung jumlah barang
$sql_barang = "SELECT * FROM barang";
$result_barang = $conn->query($sql_barang);
$jumlah_barang = $result_barang->num_rows;

// Menghitung jumlah pengguna
$sql_pengguna = "SELECT COUNT(*) as jumlah_pengguna FROM pengguna";
$result_pengguna = $conn->query($sql_pengguna);
$row_pengguna = $result_pengguna->fetch_assoc();
$jumlah_pengguna = $row_pengguna['jumlah_pengguna'];

if(isset($_POST['add_to_cart'])){
    $nama_barang = $_POST['nama_barang'];
    $harga_barang = $_POST['harga_barang'];
    $foto_barang = $_POST['foto_barang'];
    $product_quantity = 1;

    $select_cart = $conn->prepare("SELECT * FROM cart WHERE email = ? AND nama_barang = ?");
    $select_cart->bind_param("ss", $email, $nama_barang);
    $select_cart->execute();
    $result_select_cart = $select_cart->get_result();

    if($result_select_cart->num_rows > 0){
        $message[] = 'Product already added to cart';
    } else {
        $insert_product = $conn->prepare("INSERT INTO cart (email, nama_barang, harga_barang, foto_barang, quantity) VALUES (?, ?, ?, ?, ?)");
        $insert_product->bind_param("ssssd", $email, $nama_barang, $harga_barang, $foto_barang, $product_quantity);
        $insert_product->execute();
    }
}

// Menghitung total harga di keranjang
$total_harga = 0; // Variabel untuk menyimpan total harga

if ($jumlah_cart > 0) {
    while ($row = $result_cart->fetch_assoc()) {
        // Menghitung subtotal harga untuk setiap barang
        $subtotal = $row['harga_barang'] * $row['quantity'];
        
        // Menambahkan subtotal ke total harga
        $total_harga += $subtotal;
    }
}

$total_harga_format = number_format($total_harga, 2, ',', '.'); 

// Logika untuk memperbarui quantity
$update_success = false;

if (isset($_POST['update_update_btn'])) {
    // Ambil nilai dari form
    $update_quantity_id = intval($_POST['update_quantity_id']);
    $update_quantity = intval($_POST['update_quantity']);

    // Update quantity di database
    $update_query = "UPDATE cart SET quantity = ? WHERE id = ? AND email = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('iis', $update_quantity, $update_quantity_id, $email);

    if ($stmt->execute()) {
        $update_success = true;
        $message_oke = "Data Berhasil Di Ubah";
    } else {
        $message_error = "Terjadi Kesalahan Saat Memperbarui Data Barang!";
    }

    $stmt->close();
}

// Ambil data keranjang dari database berdasarkan email pengguna
$query = "SELECT * FROM cart WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email);
$stmt->execute();
$result_cart = $stmt->get_result();
$jumlah_cart = $result_cart->num_rows;

$conn->close();
?>
