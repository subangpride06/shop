<?php
 include '5xxyx089m.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../../bahan-gambar/default.png" type="image/icon">
    <title>Checkout Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
      nav {
        height: 50px; 
      }
      .navbar-brand {
        font-size: 40px;
        transform: translateY(-16px);
        margin-left: -3px;
      }
      h2 {
        margin-left: 20px;
        margin-top: 20px;
      }
      .nama_brand_footer {
        width: 150px;
      }
      .footer {
        background-color: #f8f9fa;
        padding: 20px 0;
        text-align: center;
        border-top: 1px solid #dee2e6;
        margin-top: 200px;
      }
      .footer h2 {
        margin: 0;
        font-size: 1.5rem;
      }
      .footer p {
        margin: 5px 0;
        font-size: 1rem;
        color: #6c757d;
      }
      .footer .payment-methods {
        margin: 20px 0;
      }
      .footer .payment-methods img {
        margin: 0 5px;
        height: 30px;
      }
      .footer .social-icons {
        margin: 10px 0;
      }
      .footer .social-icons a {
        margin: 0 10px;
        text-decoration: none;
        color: #343a40;
        font-size: 1.2rem;
      }
      .footer .copyright {
        margin: 10px 0;
        font-size: 0.9rem;
        color: #6c757d;
      }
      .order-details img {
        width: 150px;
        height: 100px;
        object-fit: cover;
      }
      .order-details .card {
        margin-bottom: 15px;
      }
      .order-details .card-body {
        display: flex;
        align-items: center;
      }
      .order-details .card-body h5 {
        margin: 0;
        flex: 1;
      }
      .order-details .card-body p {
        margin: 0 20px 0 0;
      }
      .order-details .card-body .qty {
        width: 60px;
      }
      .total {
        font-size: 1.5rem;
      }
      .ttl {
        margin-top: 20px;
      }
      .btn-success {
        width: 100%;
        font-size: 1.2rem;
      }
      .foto-b {
        transform: translateX(10px);
        width: 150px;
        border-radius: 4px;
      }
      .foto-b img {
        border-radius: 4px;
        box-shadow: 0px 0px 3px black;
        transform: translateY(8px);
        font-size: 100px;
    }
    .nama-b {
        font-weight: 800;
        transform: translateY(-100px);
        position: absolute;
        left: 167px;
    }
    .harga-b {
        font-weight: 800;
        color: #ff55f3;
        transform: translateY(-75px);
        position: absolute;
        left: 167px;
    }
    
    .card.cart {
        
        height: 120px;
    }
    .qty {
        transform: translateY(-45px);
        position: absolute;
        left: 167px;
        border: 2px solid black;
        border-radius: 4px;
        text-align: center;
    }
    .card.dana {
        width: 70px;
        padding-right: 5px;
        padding-left: 5px;
    }
    .card.gopay {
        width: 70px;
        margin-left: 80px;
        margin-top: -31px;
        padding-right: 5px;
        padding-left: 5px;
    }
    
    .ttl-f1 {
        margin-left: 20px;
        margin-top: 20px;
    }
    .ttl-f2 {
        margin-left: 20px;
        margin-top: -5px;
    }
    .ttl-f3 {
        margin-left: 20px;
        margin-top: -5px;
        font-size: 20px;
        font-weight: 800;
    }
    .ttl-f4 {
        margin-left: 190px;
        margin-top: -117px;
    }
    .ttl-f5 {
        margin-left: 190px;
        margin-top: -4px;
    }
    .ttl-f6 {
        margin-left: 190px;
        margin-top: -2px;
        font-weight: 800;
    }
    .payment-option {        
        cursor: pointer;
        border: 2px solid transparent;
        width: 70px;
        padding-right: 5px;
        padding-left: 5px;
        border-radius: 5px;
    }
    .payment-option.selected {
        border-color: #007bff;
        border-radius: 5px;
        box-shadow: 0px 0px 6px #909090;
    }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light sticky-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="../">
          <i class="bi bi-arrow-left-short"></i>
        </a>
      </div>
    </nav>

   
        <div class="container mt-4">
            <h2>Detail Pesanan</h2>
            <hr>
            <div class="order-details">
                <?php if ($jumlah_cart > 0): ?>
                    <?php while($row = $result_cart->fetch_assoc()): ?>
                        <div class="card cart mb-3">
                            <?php
                            $path_gambar = str_replace('../310807/uploads/', '../../310807/uploads/', $row['foto_barang']);
                            ?>
                            <div class="row g-0">
                                <div class="">
                                    <p class="foto-b"><img src="<?php echo htmlspecialchars($path_gambar); ?>" alt="Gambar Barang" class="img-fluid rounded-start"></p>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <p class="nama-b"><?php echo htmlspecialchars($row["nama_barang"]); ?></p>
                                        <p class="harga-b">Rp <?php echo number_format($row["harga_barang"], 0, ',', '.'); ?></p>
                                        <input class="qty" type="number" name="update_quantity" min="1" value="<?php echo isset($row['quantity']) ? htmlspecialchars($row['quantity']) : 1; ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>Tidak ada barang</p>
                <?php endif; ?>
            </div>
            <br>
            <label for="nama" class="form-label">Nama</label>
            <input type="text" id="nama" class="form-control" required>
            <br>
            <label for="nomor" class="form-label">No WhatsApp</label>
            <input type="number" id="nomor" class="form-control" required>
            <br>
            <label for="pembayaran" class="form-label">Pilih Pembayaran</label>
            <br>
            <div class="d-flex">
                <div class=" me-2">
                    <img src="../../bahan-gambar/dana.png" alt="Dana" class="img-fluid payment-option" onclick="selectPaymentOption(event)">
                </div>
                <div class="">
                    <img src="../../bahan-gambar/gopay.png" alt="Gopay" class="img-fluid payment-option" onclick="selectPaymentOption(event)">
                </div>
            </div>
            <br>
            <div class="d-flex">
                <input class="form-control me-2" type="text" placeholder="MASUKAN KUPON" aria-label="Kupon">
                <button class="btn btn-secondary" type="button" onclick="applyCoupon()">TERAPKAN</button>
            </div>
            <br>
            <div class="card ttl" style="background: #cdcdcd;">
                <p class="ttl-f1">Subtotal</p>
                <p class="ttl-f2">Potongan</p>
                <p class="ttl-f3">Total</p>
                <p class="ttl-f4" id="totalHarga">Rp. <?php echo $total_harga_format; ?></p>
                <p id="potongan" class="ttl-f5">Rp. 0</p>
                <p id="total" class="ttl-f6">Rp. <?php echo $total_harga_format; ?></p>
            </div>
            <br>
            <div class="text-center">
                <button type="button" onclick="sendToWhatsApp()" class="btn btn-success">PESAN SEKARANG</button>
            </div>
        </div>


    <div class="footer">
      <img class="nama_brand_footer" src="../../bahan-gambar/63a52a35c01dd_A.png" alt="">
      <br>
      <p>digital marketplace yang menyediakan berbagai layanan digital seperti suntik followers, panel protraday, script bot whatsapp, dll.</p>
      <div class="payment-methods">
        <img src="../../bahan-gambar/bca.png" alt="BCA">
        <img src="../../bahan-gambar/mandiri.png" alt="Mandiri">
        <img src="../../bahan-gambar/bni.png" alt="BNI">
        <img src="../../bahan-gambar/ovo.png" alt="OVO">
        <img src="../../bahan-gambar/gopay.png" alt="Gopay">
        <img src="../../bahan-gambar/dana.png" alt="Dana">
      </div>
      <br>
      <div class="copyright">
        Copyright &copy; SIAMD 2024 | All Right Reserved
      </div>
    </div>

    <script src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../../js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="../../assets/demo/chart-area-demo.js"></script>
    <script src="../../assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="../../assets/demo/datatables-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
