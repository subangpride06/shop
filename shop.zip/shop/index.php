<?php
session_start();
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'login.php';
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIAMD NETWORK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background: linear-gradient(135deg, cyan, black);
            color: white;
            font-family: Arial, sans-serif;
            height: 100vh;
        }

        .navbar-brand {
            font-family: 'Pacifico', cursive;
        }

        .navbar-nav .nav-link {
            color: white !important;
        }

        .navbar-nav .nav-link:hover {
            color: #f39c12 !important;
        }

        .signin-btn {
            color: white !important;
            border: 1px solid white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .signin-btn:hover {
            background: white;
            color: black !important;
        }

        h1 {
            font-size: 40px;
            font-weight: bold;
        }

        p {
            font-size: 18px;
        }

        .main-btn {
            background: #e67e22;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            border: none;
        }

        .main-btn:hover {
            background: #d35400;
        }

        .price-tag {
            font-size: 24px;
            font-weight: bold;
            margin-top: 20px;
        }

        .img-fluid {
            max-width: 500px;
            width: 100%;
            height: auto;
        }

        .social-icons a {
            color: white;
            margin: 0 10px;
            font-size: 24px;
        }

        @media (max-width: 768px) {
            .navbar-nav {
                text-align: center;
            }

            .main-content {
                flex-direction: column;
            }
        }
        .logo {
          width: 100px;
        }
        a {
          text-decoration: none;
        }
        .modal-login {
          margin-top: 150px;
        }
        .modal-login .modal-dialog {
            max-width: 400px;
        }
        .modal-login .modal-content {
            background: #383838;
            color: white;
            border-radius: 10px;
        }
        .modal-login .modal-header {
            border-bottom: 0;
        }
        .modal-login .modal-body {
            padding: 30px;
        }
        .modal-login .modal-footer {
            border-top: 0;
        }
        label {
          transform: translateY(-10px);
        }
        input {
          transform: translateY(-10px);
        }
        .form-control.password {
          padding-right: 40px;
        }
        .bi-eye {
          font-size: 1.5rem;
          position: absolute;
          top: 56%;
          right: 40px;
          transform: translateY(-50%);
          cursor: pointer;
          color: black;
         }
        .bi-eye-slash {
          font-size: 1.5rem;
          position: absolute;
          top: 56%;
          right: 40px;
          transform: translateY(-50%);
          cursor: pointer;
          color: black;
         }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="bahan-gambar/logo.png" alt="" class="logo"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Membership</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link signin-btn" href="#" data-bs-toggle="modal" data-bs-target="#loginModal">Sign In</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="row main-content align-items-center">
        <div class="col-md-6 text-center text-md-start">
            <div class="social-icons mb-3">
                <a href="#"><i class="bi bi-facebook"></i></a>
                <a href="#"><i class="bi bi-youtube"></i></a>
                <a href="#"><i class="bi bi-book"></i></a>
            </div>
            <h1>SIAMD NETWORK</h1>
            <p>Gunakan Layanan Hotspot Siamd Network Untuk Merasakan Internetan Dengan Kecepatan Yang Tinggi Tanpa Batas.</p>
            <a href="#" class="main-btn">Langganan Sekarang</a>
        </div>
        <div class="col-md-6 text-center">
            <img src="bahan-gambar/coffe.png" class="img-fluid" alt="Coffee Image">
        </div>
    </div>
</div>

<!-- Modal Login -->
<div class="modal fade modal-login" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="loginModalLabel">Login</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control email" id="email" name="email" required>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control password" id="password" name="password" required>
                        <i id="togglePassword" class="bi bi-eye"></i>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Sign In</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script>
    document.getElementById('togglePassword').addEventListener('click', function () {
        const passwordField = document.getElementById('password');
        const toggleIcon = document.getElementById('togglePassword');

        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.remove('bi-eye');
            toggleIcon.classList.add('bi-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.remove('bi-eye-slash');
            toggleIcon.classList.add('bi-eye');
        }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>