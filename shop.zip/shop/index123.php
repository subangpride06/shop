<?php
include '310807/koneksi310807/index.php';
// Query untuk mendapatkan jumlah pengguna
$sql_pengguna = "SELECT COUNT(*) as jumlah_pengguna FROM pengguna";
$result_pengguna = $conn->query($sql_pengguna);
$row_pengguna = $result_pengguna->fetch_assoc();
$jumlah_pengguna = $row_pengguna['jumlah_pengguna'];

// Menghitung jumlah barang
$sql_barang = "SELECT * FROM barang";
$result_barang = $conn->query($sql_barang);
$jumlah_barang = $result_barang->num_rows;

$conn->close();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="../bahan-gambar/default.png" type="image/icon">
    <title>Teleku V1</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
    
    <style>
      .keranjang i {
        font-size: 1.3rem;
        position: absolute;
        right: 60px;
        top: 13px;
      }
      
      .btn-group {
            position: absolute;
            right: 16px;
            top: 18px;
        }
        .dropdown-toggle {
            width: 30px; /* Sesuaikan width tombol */
            background-color: white; /* Atur background menjadi putih atau transparent */
            border: none; /* Hilangkan border */
            padding: 0; /* Hilangkan padding */
        }
        .dropdown-toggle:focus {
            box-shadow: none; /* Hilangkan shadow pada fokus */
        }
        .dropdown-menu {
            border-radius: 10px; /* Tambahkan border-radius */
        }
        
        .dropdown-toggle i {
            font-size: 20px;
        }
      
      .nav-item {
        background: #77b5fb;
        height: 30px;
        border-radius: 4px;
        transform: translateX(px);
        color: black;
      }
      
      ul {
        
      }
      
      ul li a {
        color: white;
      }
      
      button {
        border: none;
        outline: none;
        background: white;
      }
      
      .input {
        display: flex;
        justify-content: center;
        align-items: center;
      }
      
      .search {
        width: 80%;
        align-items: center;
        transform: translateY(-20px);
        height: 35px;
        border-radius: 20px;
        padding: 0px 35px 0px 20px;
        border: none;
        box-shadow: 0 0 3px black;
        margin-left: 15px;
      }
      
      .input i {
        font-size: 2rem;
      }
      
      #togglePassword {
    position: relative;
    right: 35px; /* Menempatkan ikon di sebelah kanan input */
    font-size: 24px;
    cursor: pointer;
    margin-top: -38px;
    color: black;
}
      
      .row {
          margin-top: 40px;
          padding: 20px;
      }
      
      
nav {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
    padding: 20px;
}

nav .dp {
    padding: 5px 10px;
    background-color: #a0a0af;
    color: white;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    font-size: 14px;
    width: 140px; /* Lebar tombol lebih panjang */
    height: 30px; /* Tinggi tombol lebih kecil */
    white-space: nowrap; /* Mencegah teks menumpuk ke bawah */
}

nav button:hover {
    background-color: #0056b3;
}

.product-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
}

.product-card {
    background-color: white;
    border: 1px solid #ddd;    
    border-radius: 8px;
    padding: 20px;
    width: 320px;
    box-shadow: 0px 0px 5px black;
}

.product-card img {
    width: 114%;
    height: auto;
    border-radius: 8px;
    margin-left: -20px;
    margin-top: -19px;
    
}

.product-card .nama {
    color: black;
    margin-top: 70px;
    white-space: nowrap;
    font-weight: 800;
}

.product-card .harga {
    color: red;
    font-weight: bold;
    margin-right: 180px;
    margin-top: -5px;
    white-space: nowrap;
}

.rating {
    color: gold;
    margin-top: -43px;
    margin-left: 200px;
    font-size: 1.2rem;
}

.nama_brand {
    width: 125px;
}

.nama_brand_footer {
    width: 150px;
}

        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            text-align: center;
            border-top: 1px solid #dee2e6;
            margin-top: 80px;
        }
        .footer h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        .footer p {
            margin: 5px 0;
            font-size: 1rem;
            color: #6c757d;
        }
        .footer .payment-methods {
            margin: 20px 0;
        }
        .footer .payment-methods img {
            margin: 0 5px;
            height: 30px;
        }
        .footer .social-icons {
            margin: 10px 0;
        }
        .footer .social-icons a {
            margin: 0 10px;
            text-decoration: none;
            color: #343a40;
            font-size: 1.2rem;
        }
        .footer .copyright {
            margin: 10px 0;
            font-size: 0.9rem;
            color: #6c757d;
        }

    </style>
  </head>
  <body>
    
   <nav class="navbar navbar-expand-lg bg-light sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img class="nama_brand" src="bahan-gambar/63a52a35c01dd_A.png" alt="">
        </a>
        
         <div class="btn-group">
            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <?php if(isset($_SESSION['email'])): ?>
                    <li><a class="dropdown-item" href="#">Profile</a></li>
                    <li><a class="dropdown-item" href="#">History</a></li>
                    <li><a class="dropdown-item" href="#">Tentang Toko</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../logout">Logout</a></li>
                <?php else: ?>
                    <li><a class="dropdown-item" href="../login">Login</a></li>
                    <li><a class="dropdown-item" href="../register">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
        
        <div class="keranjang" aria-labelledby="userDropdown">
            <a href="#"></a>
            <i class="bi bi-bag-check-fill"></i>
        </div>
    </div>
</nav>
    
     <div id="carouselExampleAutoplaying" class="carousel slide " style="margin-top: -20px;" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="bahan-gambar/1719234591636.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="bahan-gambar/1719234591636.jpg" class="d-block w-100" alt="">
    </div>
    <div class="carousel-item">
      <img src="bahan-gambar/1719234591636.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
<!--   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button> -->
</div> 
    
            <div class="input">
  <input type="text" class="search" placeholder="Cari Produk">
  <i id="togglePassword" class="bi bi-search"></i>
</div>
    
        <nav>
            <button class="dp">All</button>
            <button class="dp" onclick="otw()">OTW</button>
            <button class="dp" onclick="otw()">OTW</button>
            <button class="dp" onclick="otw()">OTW</button>
        </nav>
    
    
    <main>
<div class="product-list">
    <?php if ($jumlah_barang > 0): ?>
        <?php while($row = $result_barang->fetch_assoc()): ?>
            <?php
                // Mengubah jalur gambar dari ../uploads/ ke 310807/uploads/
                $path_gambar = str_replace('../../uploads/', '310807/uploads/', $row['foto_barang']);
            ?>
            <div class="product-card">
                <img src="<?php echo htmlspecialchars($path_gambar); ?>" alt="Gambar Barang" />
                <p class="nama"><?php echo htmlspecialchars($row["nama_barang"]); ?></p>
                <p class="harga">Rp <?php echo number_format($row["harga_barang"], 2, ',', '.'); ?></p>
                <div class="rating">★★★★★</div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Tidak ada data barang</p>
    <?php endif; ?>
</div>

    </main>
    
<!-- Footer Section -->
<div class="footer">
    <img class="nama_brand_footer" src="bahan-gambar/63a52a35c01dd_A.png" alt="">
    <br>
    <p>digital marketplace yang menyediakan berbagai layanan digital seperti suntik followers, panel protraday, script bot whatsapp, dll.</p>
    <div class="payment-methods">
        <img src="bahan-gambar/bca.png" alt="BCA">
        <img src="bahan-gambar/mandiri.png" alt="Mandiri">
        <img src="bahan-gambar/bni.png" alt="BNI">
        <img src="bahan-gambar/ovo.png" alt="OVO">
        <img src="bahan-gambar/gopay.png" alt="Gopay">
        <img src="bahan-gambar/dana.png" alt="Dana">
    </div>
    <br>
    <div class="copyright">
       Copyright &copy; SIAMD 2024 | All Right Reserved
    </div>
</div>
    
    
    
    <script>
        
        function otw() {
            alert("Maaf, Fitur Tersebut Tidak Dapat Digunakan Karena Aplikasi Sedang Dalam Pengembangan Lebih Lanjut 🙏");
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/chart-area-demo.js"></script>
        <script src="../assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="../assets/demo/datatables-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
